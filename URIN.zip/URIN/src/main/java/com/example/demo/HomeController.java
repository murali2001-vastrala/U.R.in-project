package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String home() {
		return "Home";
	}
	
	@RequestMapping("/Aboutus")
	public String aboutUS() {
		return "Aboutus";
	}
	
	@RequestMapping("/Logins")
	public String logins() {
		return "Logins";
	}
	
	@RequestMapping("/Applicantlogin")
	public String Applicantlogin() {
		return "Applicantlogin";
	}
	
	@RequestMapping("/Applicantregister")
	public String Applicantregister() {
		return "Applicantregister";
	}
	
	@RequestMapping("/Applicanthome")
	public String applicanthome() {
		return "Applicanthome";
	}
	
	@RequestMapping("/Recrutierlogin")
	public String recrutierlogin() {
		return "Recrutierlogin";
	}
	
	@RequestMapping("/Recrutierregister")
	public String recrutierregister() {
		return "Recrutierregister";
	}
	
	@RequestMapping("/Recrutierhome")
	public String recrutierhome() {
		return "Recrutierhome";
	}
	
	@RequestMapping("/Technicianlogin")
	public String technicianlogin() {
		return "Technicianlogin";
	}
	
	@RequestMapping("/Technicianhome")
	public String technicianhome() {
		return "Technicianhome";
	}
	
	@RequestMapping("Searchjob")
	public String searchjob() {
		return "Searchjob";
	}
	
	
}
